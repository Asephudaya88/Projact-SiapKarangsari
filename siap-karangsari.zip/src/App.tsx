/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, type ReactNode } from 'react';
import { Camera, Users, History, LayoutDashboard, ShieldCheck, LogOut, Settings as SettingsIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import OfficialManagement from './components/OfficialManagement';
import AttendanceSystem from './components/AttendanceSystem';
import HistoryReport from './components/HistoryReport';
import Settings from './components/Settings';
import Login from './components/Login';

const LOGO_URL = "/logo.png";

type Tab = 'absensi' | 'perangkat' | 'riwayat' | 'pengaturan';

export default function App() {
  const [user, setUser] = useState<{ name: string; role: 'admin' | 'official'; id?: string } | null>(() => {
    const saved = localStorage.getItem('siap_auth');
    return saved ? JSON.parse(saved) : null;
  });
  const [activeTab, setActiveTab] = useState<Tab>('absensi');

  const handleLogout = () => {
    localStorage.removeItem('siap_auth');
    setUser(null);
  };

  if (!user) {
    return <Login onLogin={(userData) => setUser(userData)} />;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row text-slate-900">
      {/* Sidebar Navigation */}
      <nav className="w-full md:w-64 bg-slate-900 text-white flex flex-col border-r border-slate-800 z-50">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="bg-white p-1.5 rounded-xl shadow-lg shadow-blue-500/10 overflow-hidden flex items-center justify-center">
              <img 
                src={LOGO_URL} 
                alt="Logo Desa" 
                className="w-9 h-9 object-contain" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight leading-none text-white">SIAP</h1>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Karangsari</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <NavItem 
              icon={<Camera size={20} />} 
              label="Absensi Digital" 
              active={activeTab === 'absensi'} 
              onClick={() => setActiveTab('absensi')} 
            />
            <NavItem 
              icon={<Users size={20} />} 
              label="Data Perangkat" 
              active={activeTab === 'perangkat'} 
              onClick={() => setActiveTab('perangkat')} 
            />
            <NavItem 
              icon={<History size={20} />} 
              label="Riwayat & Laporan" 
              active={activeTab === 'riwayat'} 
              onClick={() => setActiveTab('riwayat')} 
            />
            <NavItem 
              icon={<SettingsIcon size={20} />} 
              label="Pengaturan" 
              active={activeTab === 'pengaturan'} 
              onClick={() => setActiveTab('pengaturan')} 
            />
          </div>
        </div>

        <div className="mt-auto p-6 border-t border-slate-800 space-y-4">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition"
          >
            <LogOut size={18} />
            <span className="text-sm font-semibold">Keluar</span>
          </button>

          <div>
            <div className="flex items-center gap-3 text-slate-500 text-xs text-slate-500">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              Sistem Aktif (Lokal)
            </div>
            <p className="text-[10px] text-slate-600 mt-2">© 2024 Pemdes Karangsari</p>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto bg-brand-light">
        <header className="sticky top-0 bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex justify-between items-center z-40">
          <div className="flex items-center gap-2 text-slate-500 font-medium text-sm">
            <LayoutDashboard size={14} />
            <span>Dashboard</span>
            <span className="text-slate-300">/</span>
            <span className="text-slate-900 capitalize font-semibold">{activeTab}</span>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="text-right hidden sm:block">
               <p className="text-xs font-bold text-slate-900">{user.name}</p>
               <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">{user.role === 'admin' ? 'Administrator' : 'Perangkat Desa'}</p>
             </div>
             <div className="flex items-center gap-2 bg-slate-50 p-1 pr-3 rounded-full border border-slate-200">
               <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400 font-bold overflow-hidden shadow-sm">
                  <img src={LOGO_URL} alt="Logo" className="w-6 h-6 object-contain" referrerPolicy="no-referrer" />
               </div>
               <div className="w-8 h-8 rounded-full bg-brand-blue flex items-center justify-center text-white text-[10px] font-bold overflow-hidden shadow-md">
                 <img src={`https://ui-avatars.com/api/?name=${user.name}&background=1d4ed8&color=ffffff&bold=true`} alt={user.name} />
               </div>
             </div>
          </div>
        </header>

        <section className="p-8 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'absensi' && <AttendanceSystem preselectedId={user.id} />}
              {activeTab === 'perangkat' && <OfficialManagement />}
              {activeTab === 'riwayat' && <HistoryReport isAdmin={user.role === 'admin'} />}
              {activeTab === 'pengaturan' && <Settings />}
            </motion.div>
          </AnimatePresence>
        </section>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
        active 
        ? 'bg-brand-blue text-white shadow-lg shadow-blue-600/20' 
        : 'text-slate-400 hover:text-white hover:bg-slate-800'
      }`}
    >
      <span className={`${active ? 'text-white' : 'text-slate-500 group-hover:text-white'} transition-colors`}>
        {icon}
      </span>
      <span className="font-semibold text-sm">{label}</span>
      {active && (
        <motion.div
          layoutId="active-pill"
          className="ml-auto w-1.5 h-1.5 rounded-full bg-white"
        />
      )}
    </button>
  );
}
