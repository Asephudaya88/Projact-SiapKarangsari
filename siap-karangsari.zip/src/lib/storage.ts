
import { Official, AttendanceRecord } from '../types';

const OFFICIALS_KEY = 'siap_karangsari_officials';
const ATTENDANCE_KEY = 'siap_karangsari_attendance';
const OFFICE_KEY = 'siap_karangsari_office';

export const storage = {
  getOffice: () => {
    const data = localStorage.getItem(OFFICE_KEY);
    return data ? JSON.parse(data) : { lat: -7.576479, lng: 107.618333, radius: 100 }; // Default Desa Karangsari
  },
  setOffice: (office: { lat: number, lng: number, radius: number }) => {
    localStorage.setItem(OFFICE_KEY, JSON.stringify(office));
  },
  getOfficials: (): Official[] => {
    const data = localStorage.getItem(OFFICIALS_KEY);
    return data ? JSON.parse(data) : [];
  },
  saveOfficial: (official: Official) => {
    const officials = storage.getOfficials();
    const index = officials.findIndex(o => o.id === official.id);
    if (index >= 0) {
      officials[index] = official;
    } else {
      officials.push(official);
    }
    localStorage.setItem(OFFICIALS_KEY, JSON.stringify(officials));
  },
  deleteOfficial: (id: string) => {
    const officials = storage.getOfficials().filter(o => o.id !== id);
    localStorage.setItem(OFFICIALS_KEY, JSON.stringify(officials));
  },
  getAttendance: (): AttendanceRecord[] => {
    const data = localStorage.getItem(ATTENDANCE_KEY);
    return data ? JSON.parse(data) : [];
  },
  saveAttendance: (record: AttendanceRecord) => {
    try {
      const attendance = storage.getAttendance();
      attendance.push(record);
      localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(attendance));
      return true;
    } catch (e) {
      console.error("Storage error:", e);
      return false;
    }
  },
  saveAllAttendance: (records: AttendanceRecord[]) => {
    localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(records));
  },
  clearAll: () => {
    localStorage.removeItem(OFFICIALS_KEY);
    localStorage.removeItem(ATTENDANCE_KEY);
  }
};
