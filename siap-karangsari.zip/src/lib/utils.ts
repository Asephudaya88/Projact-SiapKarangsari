
import { WORK_HOURS } from '../types';

export const formatTime = (date: Date) => {
  return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
};

export const formatDate = (date: Date) => {
  return date.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
};

export const isWithinTimeRange = (current: string, start: string, end: string) => {
  return current >= start && current <= end;
};

export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371e3; // meters
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // distance in meters
};

export const getShiftStatus = () => {
  const now = new Date();
  const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
  
  if (timeStr < WORK_HOURS.START) return { label: 'Belum Mulai', color: 'text-amber-500' };
  if (timeStr > WORK_HOURS.END) return { label: 'Sudah Berakhir', color: 'text-red-500' };
  return { label: 'Waktu Bertugas', color: 'text-green-500' };
};
