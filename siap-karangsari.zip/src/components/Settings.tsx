import React, { useState, useEffect } from 'react';
import { storage } from '../lib/storage';
import { MapPin, Save, ShieldAlert, Crosshair } from 'lucide-react';
import { motion } from 'motion/react';

export default function Settings() {
  const [office, setOffice] = useState({ lat: 0, lng: 0, radius: 10 });
  const [isLocating, setIsLocating] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    setOffice(storage.getOffice());
  }, []);

  const handleSave = () => {
    storage.setOffice(office);
    setMessage('Pengaturan lokasi kantor berhasil disimpan!');
    setTimeout(() => setMessage(''), 3000);
  };

  const detectCurrentLocation = () => {
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setOffice({ ...office, lat: pos.coords.latitude, lng: pos.coords.longitude });
        setIsLocating(false);
      },
      (err) => {
        alert('Gagal mendapatkan lokasi. Pastikan izin GPS aktif.');
        setIsLocating(false);
      },
      { enableHighAccuracy: true }
    );
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="bg-amber-100 p-3 rounded-2xl text-amber-600">
            <MapPin size={28} />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Pengaturan Lokasi Kantor</h2>
            <p className="text-slate-500 text-sm">Tentukan koordinat pusat kantor desa Karangsari</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Latitude</label>
            <input
              type="number"
              step="any"
              className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-blue"
              value={office.lat}
              onChange={e => setOffice({ ...office, lat: parseFloat(e.target.value) })}
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Longitude</label>
            <input
              type="number"
              step="any"
              className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-blue"
              value={office.lng}
              onChange={e => setOffice({ ...office, lng: parseFloat(e.target.value) })}
            />
          </div>
          <div className="md:col-span-2 space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Radius Maksimal (Meter)</label>
            <div className="flex gap-4 items-center">
              <input
                type="number"
                className="flex-1 p-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-blue"
                value={office.radius}
                onChange={e => setOffice({ ...office, radius: parseFloat(e.target.value) })}
              />
              <span className="text-slate-400 font-bold">m</span>
            </div>
            <p className="text-[10px] text-amber-600 font-medium">*Absensi di luar radius ini akan ditolak otomatis.</p>
          </div>
        </div>

        <div className="flex flex-col gap-3 pt-4">
          <button
            onClick={detectCurrentLocation}
            disabled={isLocating}
            className="w-full py-3 bg-slate-100 text-slate-700 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-200 transition"
          >
            <Crosshair size={20} className={isLocating ? 'animate-spin' : ''} />
            {isLocating ? 'Mendeteksi Lokasi...' : 'Gunakan Lokasi Saya Saat Ini'}
          </button>
          
          <button
            onClick={handleSave}
            className="w-full py-4 bg-brand-blue text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-100 hover:bg-blue-700 transition flex items-center justify-center gap-2"
          >
            <Save size={20} />
            Simpan Konfigurasi
          </button>
        </div>

        {message && (
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center text-green-600 font-bold text-sm">
            {message}
          </motion.p>
        )}
      </div>

      <div className="bg-red-50 border border-red-100 p-6 rounded-3xl flex gap-4">
        <ShieldAlert className="text-red-500 shrink-0" size={24} />
        <div>
          <h4 className="text-red-800 font-bold text-sm">Peringatan Keamanan GPS</h4>
          <p className="text-red-600 text-xs mt-1 leading-relaxed">
            Radius 5 meter sangat ketat. Akurasi GPS ponsel rata-rata adalah 5-15 meter. 
            Jika perangkat desa berada di dalam kantor namun GPS meleset, absensi mungkin ditolak.
            Disarankan menggunakan radius minimal 20-50 meter untuk penggunaan lapangan yang stabil.
          </p>
        </div>
      </div>
    </div>
  );
}
