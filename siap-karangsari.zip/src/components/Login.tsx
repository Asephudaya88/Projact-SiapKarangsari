import React, { useState, useEffect } from 'react';
import { ShieldCheck, Lock, User as UserIcon, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { storage } from '../lib/storage';
import { Official } from '../types';

interface LoginProps {
  onLogin: (user: { name: string; role: 'admin' | 'official' }) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [officials, setOfficials] = useState<Official[]>([]);

  useEffect(() => {
    setOfficials(storage.getOfficials());
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const commonPass = 'Absen26';
    
    // Check Admin
    if (username === 'Karangsari Ok' && password === commonPass) {
      const userData = { name: 'Admin Karangsari', role: 'admin' as const };
      localStorage.setItem('siap_auth', JSON.stringify(userData));
      onLogin(userData);
      return;
    }

    // Check Official NIK/NIPD
    const foundOfficial = officials.find(o => 
      o.officialId === username
    );

    if (foundOfficial && password === commonPass) {
      const userData = { name: foundOfficial.name, role: 'official' as const, id: foundOfficial.id };
      localStorage.setItem('siap_auth', JSON.stringify(userData));
      onLogin(userData);
    } else {
      setError('NIK/NIPD atau Password salah!');
    }
  };

  return (
    <div className="min-h-screen bg-brand-light flex items-center justify-center p-6 text-slate-900">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden"
      >
        <div className="bg-brand-blue p-8 text-white text-center">
          <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 backdrop-blur-md border border-white/30">
            <ShieldCheck size={32} />
          </div>
          <h1 className="text-2xl font-black tracking-tight">SIAP Karangsari</h1>
          <p className="text-blue-100 text-sm mt-1">Sistem Informasi Absensi Perangkat</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="bg-blue-50 p-3 rounded-xl text-[10px] text-blue-700 font-bold uppercase leading-tight">
            Gunakan NIK/NIPD Anda sebagai Username dan "Absen26" sebagai Password.
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-red-50 text-red-600 p-3 rounded-xl flex items-center gap-2 text-xs font-bold border border-red-100"
            >
              <AlertCircle size={18} />
              {error}
            </motion.div>
          )}

          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">NIK/NIPD / Username Admin</label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  required
                  type="text"
                  placeholder="Masukkan NIK atau NIPD"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-blue transition"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  required
                  type="password"
                  placeholder="Masukkan password"
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-blue transition"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-brand-blue text-white rounded-xl font-bold text-lg shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-[0.98] transition-all"
          >
            MASUK APLIKASI
          </button>

          <p className="text-center text-xs text-slate-400 font-medium">
            Pemerintah Desa Karangsari <br/> 
            Kecamatan Karangpawitan
          </p>
        </form>
      </motion.div>
    </div>
  );
}

