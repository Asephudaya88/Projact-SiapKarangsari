
import React, { useState, useEffect } from 'react';
import { Official } from '../types';
import { storage } from '../lib/storage';
import { Plus, Trash2, Edit2, Users, MapPin, Briefcase } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function OfficialManagement() {
  const [officials, setOfficials] = useState<Official[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({ name: '', position: '', address: '', officialId: '' });

  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    setOfficials(storage.getOfficials());
  }, []);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const newOfficial: Official = {
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      createdAt: Date.now()
    };
    storage.saveOfficial(newOfficial);
    setOfficials(storage.getOfficials());
    setFormData({ name: '', position: '', address: '', officialId: '' });
    setIsAdding(false);
  };

  const handleDelete = (id: string) => {
    storage.deleteOfficial(id);
    setOfficials(storage.getOfficials());
    setDeletingId(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Daftar Perangkat Desa</h2>
          <p className="text-slate-500 text-sm">Kelola data personal pemerintah desa Karangsari</p>
        </div>
        <div className="flex gap-2">
          {officials.length > 0 && (
            <button
              onClick={() => {
                if (window.confirm('Hapus SEMUA data perangkat desa?')) {
                  localStorage.removeItem('siap_karangsari_officials');
                  setOfficials([]);
                }
              }}
              className="px-4 py-2 border border-red-200 text-red-600 rounded-lg text-sm font-bold hover:bg-red-50 transition"
            >
              Hapus Semua
            </button>
          )}
          <button
            onClick={() => setIsAdding(true)}
            className="bg-brand-blue text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition shadow-md"
          >
            <Plus size={20} />
            Tambah Perangkat
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm"
          >
            <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 uppercase">NIK / NIPD</label>
                <input
                  required
                  type="text"
                  placeholder="Contoh: 3205..."
                  className="w-full p-2 border border-slate-200 rounded-md focus:ring-2 focus:ring-brand-blue outline-none font-mono"
                  value={formData.officialId}
                  onChange={e => setFormData({ ...formData, officialId: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 uppercase">Nama Lengkap</label>
                <input
                  required
                  type="text"
                  placeholder="Contoh: Asep Saepul"
                  className="w-full p-2 border border-slate-200 rounded-md focus:ring-2 focus:ring-brand-blue outline-none"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 uppercase">Jabatan</label>
                <input
                  required
                  type="text"
                  placeholder="Contoh: Kepala Desa"
                  className="w-full p-2 border border-slate-200 rounded-md focus:ring-2 focus:ring-brand-blue outline-none"
                  value={formData.position}
                  onChange={e => setFormData({ ...formData, position: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 uppercase">Alamat</label>
                <input
                  required
                  type="text"
                  placeholder="Dusun Karangsari RT 01..."
                  className="w-full p-2 border border-slate-200 rounded-md focus:ring-2 focus:ring-brand-blue outline-none"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                />
              </div>
              <div className="md:col-span-3 flex justify-end gap-2 pt-2 border-top">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-50 rounded-md transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="bg-slate-900 text-white px-6 py-2 rounded-md hover:bg-slate-800 transition"
                >
                  Simpan Data
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {officials.map((official) => (
          <motion.div
            key={official.id}
            layout
            className="bg-white p-5 rounded-xl border border-slate-200 hover:border-brand-blue transition group shadow-sm relative overflow-hidden"
          >
            {deletingId === official.id && (
              <div className="absolute inset-0 bg-red-600/95 flex flex-col items-center justify-center text-white z-10 p-4 text-center">
                <p className="font-bold mb-3 text-sm">Hapus data {official.name}?</p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setDeletingId(null)}
                    className="px-3 py-1 bg-white/20 hover:bg-white/30 rounded text-xs font-bold"
                  >
                    Batal
                  </button>
                  <button 
                    onClick={() => handleDelete(official.id)}
                    className="px-3 py-1 bg-white text-red-600 rounded text-xs font-bold shadow-lg"
                  >
                    Ya, Hapus
                  </button>
                </div>
              </div>
            )}
            <div className="flex justify-between items-start mb-4">
              <div className="bg-blue-50 p-2 rounded-full text-brand-blue">
                <Users size={24} />
              </div>
              <button
                onClick={() => setDeletingId(official.id)}
                className="text-slate-400 hover:text-red-500 transition-colors p-2 bg-slate-50 rounded-lg"
                title="Hapus Perangkat"
              >
                <Trash2 size={18} />
              </button>
            </div>
            <h3 className="text-lg font-black text-slate-800 mb-1">{official.name}</h3>
            <p className="text-[10px] font-bold text-slate-400 mb-3 tracking-widest uppercase">NIK: {official.officialId || '-'}</p>
            <div className="space-y-2 text-sm text-slate-600">
              <div className="flex items-center gap-2">
                <Briefcase size={14} className="text-slate-400" />
                <span>{official.position}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={14} className="text-slate-400" />
                <span className="truncate">{official.address}</span>
              </div>
            </div>
          </motion.div>
        ))}
        {officials.length === 0 && !isAdding && (
          <div className="col-span-full py-12 text-center bg-white rounded-xl border border-dashed border-slate-300">
            <Users className="mx-auto text-slate-300 mb-2" size={48} />
            <p className="text-slate-400">Belum ada data perangkat desa.</p>
            <button onClick={() => setIsAdding(true)} className="text-brand-blue font-semibold mt-2 hover:underline">
              Tambah data sekarang
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
