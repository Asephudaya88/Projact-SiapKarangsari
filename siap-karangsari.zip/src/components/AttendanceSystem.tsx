
import React, { useState, useRef, useEffect } from 'react';
import { Official, AttendanceRecord, WORK_HOURS } from '../types';
import { storage } from '../lib/storage';
import { Camera, MapPin, CheckCircle2, AlertCircle, RefreshCw, LogIn, LogOut, FileText, Briefcase } from 'lucide-react';
import { motion } from 'motion/react';
import { getShiftStatus, formatTime, calculateDistance } from '../lib/utils';
import confetti from 'canvas-confetti';

interface AttendanceSystemProps {
  preselectedId?: string;
}

export default function AttendanceSystem({ preselectedId }: AttendanceSystemProps) {
  const [officials, setOfficials] = useState<Official[]>([]);
  const [selectedOfficial, setSelectedOfficial] = useState<string>(preselectedId || '');
  const [attendanceType, setAttendanceType] = useState<'MASUK' | 'PULANG' | 'IZIN' | 'TUGAS_LUAR'>('MASUK');
  const [note, setNote] = useState('');
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const [location, setLocation] = useState<GeolocationPosition | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [distanceInfo, setDistanceInfo] = useState<{ dist: number, allowed: boolean } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    setOfficials(storage.getOfficials());
    requestLocation();
  }, []);

  const requestLocation = () => {
    setIsLocating(true);
    setError(null);
    setDistanceInfo(null);
    if (!navigator.geolocation) {
      setError("Browser tidak mendukung GPS");
      setIsLocating(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation(pos);
        setIsLocating(false);
        
        // Calculate distance to office
        const office = storage.getOffice();
        const dist = calculateDistance(
          pos.coords.latitude, 
          pos.coords.longitude, 
          office.lat, 
          office.lng
        );
        setDistanceInfo({ dist, allowed: dist <= office.radius });
      },
      (err) => {
        setError("Gagal mendapatkan lokasi GPS. Pastikan izin lokasi aktif.");
        setIsLocating(false);
        console.error(err);
      },
      { enableHighAccuracy: true }
    );
  };

  const startCamera = async () => {
    setError(null);
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setError("Browser Anda tidak mendukung fitur kamera.");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }, 
        audio: false 
      });
      streamRef.current = stream;
      setIsCameraActive(true);
      setPhoto(null);
      
      // Wait for next tick to ensure videoRef is populated
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch (err) {
      console.error(err);
      setError("Gagal mengakses kamera. Pastikan izin kamera diberikan di pengaturan browser.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      setIsCameraActive(false);
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setPhoto(dataUrl);
        stopCamera();
      }
    }
  };

  const handleSubmit = async () => {
    if (!selectedOfficial || !photo || !location) {
      setError("Mohon lengkapi: Nama Perangkat, Foto Selfie, dan Lokasi GPS (Tekan tombol Refresh di status lokasi jika GPS belum muncul).");
      return;
    }

    if ((attendanceType === 'IZIN' || attendanceType === 'TUGAS_LUAR') && !note.trim()) {
      setError(`Untuk tipe ${attendanceType === 'IZIN' ? 'Izin' : 'Tugas Lapangan'}, kolom Keterangan wajib diisi.`);
      return;
    }

    // Check Distance Restriction (Except for TUGAS_LUAR)
    const office = storage.getOffice();
    const currentDist = calculateDistance(
      location.coords.latitude,
      location.coords.longitude,
      office.lat,
      office.lng
    );

    if (attendanceType !== 'TUGAS_LUAR' && currentDist > office.radius) {
      setError(`ABSENSI DITOLAK: Lokasi Anda terlalu jauh dari kantor (${Math.round(currentDist)}m). Batas maksimal: ${office.radius}m.`);
      return;
    }

    setIsSaving(true);
    const official = officials.find(o => o.id === selectedOfficial);
    
    const record: AttendanceRecord = {
      id: Date.now().toString(),
      officialId: selectedOfficial,
      officialName: official?.name || 'Unknown',
      type: attendanceType,
      status: 'PENDING',
      timestamp: Date.now(),
      photo: photo,
      location: {
        lat: location.coords.latitude,
        lng: location.coords.longitude,
        accuracy: location.coords.accuracy
      },
      note: note
    };

    // Save to storage
    setTimeout(() => {
      const saved = storage.saveAttendance(record);
      setIsSaving(false);
      
      if (!saved) {
        setError("GAGAL MENYIMPAN: Memori penyimpanan penuh. Hubungi admin untuk membersihkan data riwayat di menu Pengaturan.");
        return;
      }

      setSuccess(true);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      
      // Reset after success
      setTimeout(() => {
        setSuccess(false);
        setPhoto(null);
        setSelectedOfficial('');
        setNote('');
        setAttendanceType('MASUK');
      }, 3000);
    }, 1000);
  };

  const shiftStatus = getShiftStatus();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="bg-brand-blue p-6 text-white">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-bold">Siap Absen Hari Ini?</h2>
              <p className="opacity-80 text-sm">Desa Karangsari • {new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-xs font-bold bg-white/20 border border-white/30 backdrop-blur-sm`}>
              <span className={shiftStatus.color}>{shiftStatus.label}</span>
            </div>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left: Input & Location */}
          <div className="space-y-6">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Pilih Perangkat Desa</label>
              <select
                className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 outline-none focus:ring-2 focus:ring-brand-blue font-semibold"
                value={selectedOfficial}
                onChange={(e) => setSelectedOfficial(e.target.value)}
              >
                <option value="">-- Pilih Nama --</option>
                {officials.length === 0 && <option value="" disabled>Belum ada data perangkat desa</option>}
                {officials.map(o => (
                  <option key={o.id} value={o.id}>{o.name} ({o.position})</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Tipe Absensi</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setAttendanceType('MASUK')}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition ${attendanceType === 'MASUK' ? 'bg-blue-50 border-brand-blue text-brand-blue' : 'border-slate-200 text-slate-400'}`}
                >
                  <LogIn size={20} />
                  <span className="text-[10px] font-bold">Datang</span>
                </button>
                <button
                  onClick={() => setAttendanceType('PULANG')}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition ${attendanceType === 'PULANG' ? 'bg-red-50 border-red-500 text-red-500' : 'border-slate-200 text-slate-400'}`}
                >
                  <LogOut size={20} />
                  <span className="text-[10px] font-bold">Pulang</span>
                </button>
                <button
                  onClick={() => setAttendanceType('IZIN')}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition ${attendanceType === 'IZIN' ? 'bg-amber-50 border-amber-500 text-amber-600' : 'border-slate-200 text-slate-400'}`}
                >
                  <FileText size={20} />
                  <span className="text-[10px] font-bold uppercase text-center">Izin Keluarga</span>
                </button>
                <button
                  onClick={() => setAttendanceType('TUGAS_LUAR')}
                  className={`p-3 rounded-xl border flex flex-col items-center gap-1 transition ${attendanceType === 'TUGAS_LUAR' ? 'bg-purple-50 border-purple-500 text-purple-600' : 'border-slate-200 text-slate-400'}`}
                >
                  <Briefcase size={20} />
                  <span className="text-[10px] font-bold uppercase text-center">Tugas Lapangan</span>
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Keterangan / Catatan</label>
              <textarea
                placeholder="Masukkan keterangan tambahan jika perlu (wajib jika Izin/Tugas Lapangan)"
                className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 outline-none focus:ring-2 focus:ring-brand-blue h-20 text-sm"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-slate-600 font-semibold text-sm">
                  <MapPin size={16} />
                  Status Lokasi GPS
                </div>
                <button 
                  onClick={requestLocation}
                  disabled={isLocating}
                  className="p-1 hover:bg-slate-200 rounded-full transition text-slate-400"
                >
                  <RefreshCw size={16} className={isLocating ? 'animate-spin' : ''} />
                </button>
              </div>
              
              {isLocating ? (
                <div className="text-xs text-slate-400 italic">Mencari koordinat...</div>
              ) : location ? (
                <div className="space-y-1">
                  <p className="text-xs text-slate-500 font-mono">
                    Lat: {location.coords.latitude.toFixed(6)} <br/>
                    Lng: {location.coords.longitude.toFixed(6)}
                  </p>
                  <div className="flex items-center gap-1 text-[10px] text-green-600 font-bold uppercase transition-all">
                    <CheckCircle2 size={10} />
                    GPS Terverifikasi (Akurasi: {location.coords.accuracy.toFixed(1)}m)
                  </div>
                  {distanceInfo && (
                    <div className={`mt-2 p-2 rounded-lg text-[10px] font-bold uppercase flex items-center gap-2 ${
                      distanceInfo.allowed ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'
                    }`}>
                      {distanceInfo.allowed ? <CheckCircle2 size={12}/> : <AlertCircle size={12}/>}
                      Jarak ke Kantor: {Math.round(distanceInfo.dist)} Meter 
                      ({distanceInfo.allowed ? 'DALAM RADIUS' : 'DI LUAR RADIUS'})
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-2 text-red-500 text-xs font-semibold">
                  <AlertCircle size={14} />
                  GPS Belum Terdeteksi
                </div>
              )}
            </div>
          </div>

          {/* Right: Camera */}
          <div className="space-y-4">
            <label className="text-xs font-bold text-slate-500 uppercase block">Verifikasi Poto Selfie</label>
            <div className="aspect-square bg-slate-100 rounded-2xl border-2 border-dashed border-slate-300 relative overflow-hidden flex items-center justify-center">
              {isCameraActive ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-cover"
                />
              ) : photo ? (
                <img src={photo} className="w-full h-full object-cover" alt="Selfie" />
              ) : (
                <div className="text-center p-8 space-y-4">
                  <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center mx-auto shadow-sm text-slate-400">
                    <Camera size={32} />
                  </div>
                  <p className="text-sm text-slate-400 px-4">Ambil foto selfie di depan kantor untuk verifikasi kehadiran.</p>
                </div>
              )}

              {isCameraActive && (
                <button
                  onClick={takePhoto}
                  className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-white w-14 h-14 rounded-full border-4 border-brand-blue/30 flex items-center justify-center shadow-lg active:scale-95 transition"
                >
                  <div className="w-10 h-10 bg-brand-blue rounded-full shadow-inner" />
                </button>
              )}
            </div>

            {!isCameraActive && !photo && (
              <button
                onClick={startCamera}
                className="w-full py-4 bg-slate-900 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition shadow-lg shadow-slate-200 animate-pulse hover:animate-none"
              >
                <Camera size={24} />
                BUKA KAMERA SEKARANG
              </button>
            )}

            {isCameraActive && (
              <button
                onClick={stopCamera}
                className="w-full py-3 bg-red-100 text-red-600 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-red-200 transition"
              >
                Tutup Kamera
              </button>
            )}

            {photo && (
              <button
                onClick={startCamera}
                className="w-full py-3 bg-white text-slate-600 border border-slate-200 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-50 transition"
              >
                <RefreshCw size={20} />
                Ambil Ulang Foto
              </button>
            )}
          </div>
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-200">
          <button
            disabled={isSaving || success}
            onClick={handleSubmit}
            className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-3 transition-all ${
              success 
              ? 'bg-green-500 text-white translate-y-0' 
              : 'bg-brand-blue text-white hover:bg-blue-700 active:scale-[0.98] disabled:bg-slate-300 disabled:shadow-none'
            }`}
          >
            {isSaving ? (
              <>
                <RefreshCw className="animate-spin" size={24} />
                Memproses Absensi...
              </>
            ) : success ? (
              <>
                <CheckCircle2 size={24} />
                Absensi Berhasil!
              </>
            ) : (
              <>
                Kirim Absensi Sekarang
              </>
            )}
          </button>
          
          {error && (
            <div className="bg-red-50 border border-red-100 p-4 rounded-xl mt-4 flex items-start gap-3">
              <AlertCircle className="text-red-500 flex-shrink-0 mt-0.5" size={18} />
              <p className="text-red-600 text-sm font-semibold">
                {error}
              </p>
            </div>
          )}
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
