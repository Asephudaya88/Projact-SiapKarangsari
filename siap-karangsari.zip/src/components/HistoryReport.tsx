
import React, { useState, useEffect } from 'react';
import { AttendanceRecord } from '../types';
import { storage } from '../lib/storage';
import { FileSpreadsheet, Download, Search, MapPin, Clock, Calendar, CheckCircle2, AlertCircle, RefreshCw, LogIn, LogOut, FileText } from 'lucide-react';
import * as XLSX from 'xlsx';
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, AlignmentType, WidthType, BorderStyle, VerticalAlign, HeadingLevel, ImageRun } from 'docx';
import { saveAs } from 'file-saver';
import { motion } from 'motion/react';
import { formatDate, formatTime } from '../lib/utils';

const LOGO_URL = "/logo.png";

const fetchImageAsBuffer = async (url: string) => {
  const response = await fetch(url);
  const buffer = await response.arrayBuffer();
  return new Uint8Array(buffer);
};

interface HistoryReportProps {
  isAdmin?: boolean;
}

export default function HistoryReport({ isAdmin }: HistoryReportProps) {
  const [history, setHistory] = useState<AttendanceRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  const [isExportingWord, setIsExportingWord] = useState(false);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setHistory(storage.getAttendance().sort((a, b) => b.timestamp - a.timestamp));
  };

  const exportToWord = async () => {
    setIsExportingWord(true);
    try {
      const logoBuffer = await fetchImageAsBuffer(LOGO_URL);

      const doc = new Document({
        sections: [
          {
            properties: {},
            children: [
              // Kop Surat Table
              new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                borders: {
                  top: { style: BorderStyle.NONE },
                  bottom: { style: BorderStyle.NONE },
                  left: { style: BorderStyle.NONE },
                  right: { style: BorderStyle.NONE },
                  insideHorizontal: { style: BorderStyle.NONE },
                  insideVertical: { style: BorderStyle.NONE },
                },
                rows: [
                  new TableRow({
                    children: [
                      // Logo Cell
                      new TableCell({
                        width: { size: 15, type: WidthType.PERCENTAGE },
                        verticalAlign: VerticalAlign.CENTER,
                        children: [
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [
                              new ImageRun({
                                data: logoBuffer,
                                transformation: { width: 80, height: 80 },
                              } as any),
                            ],
                          }),
                        ],
                      }),
                      // Text Cell
                      new TableCell({
                        width: { size: 85, type: WidthType.PERCENTAGE },
                        verticalAlign: VerticalAlign.CENTER,
                        children: [
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [
                              new TextRun({ text: "PEMERINTAH KABUPATEN GARUT", bold: true, size: 28 }),
                            ],
                          }),
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [
                              new TextRun({ text: "KECAMATAN PAKENJENG", bold: true, size: 26 }),
                            ],
                          }),
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [
                              new TextRun({ text: "DESA KARANGSARI", bold: true, size: 36, color: "1d4ed8" }),
                            ],
                          }),
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [
                              new TextRun({ text: "Alamat : Kp. Mekarsari RT 001 RW 013 Desa Karangsari Kec. Pakenjeng Kab. Garut 44164", size: 18 }),
                            ],
                          }),
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [
                              new TextRun({ text: "Email : desakarangsari497@gmail.com | Website : https://Karangsari.id", size: 18 }),
                            ],
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              }),
              new Paragraph({
                children: [new TextRun({ text: "", break: 1 })],
                border: { bottom: { color: "000000", space: 1, style: BorderStyle.SINGLE, size: 12 } },
              }),
              new Paragraph({ children: [new TextRun({ text: "", break: 1 })] }),
              
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({ text: "LAPORAN REKAPITULASI KEHADIRAN PERANGKAT DESA", bold: true, size: 24, underline: {} }),
                ],
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({ text: `Dicetak pada: ${new Date().toLocaleDateString('id-ID')} ${new Date().toLocaleTimeString('id-ID')}`, size: 16, italics: true }),
                ],
              }),
              new Paragraph({ children: [new TextRun({ text: "", break: 1 })] }),

              // Table
              new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                rows: [
                  // Header Row
                  new TableRow({
                    tableHeader: true,
                    children: [
                      "No", "Tanggal", "Nama Perangkat", "Tipe", "Status", "Keterangan"
                    ].map(text => new TableCell({
                      shading: { fill: "f1f5f9" },
                      verticalAlign: VerticalAlign.CENTER,
                      children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text, bold: true, size: 18 })] })]
                    }))
                  }),
                  // Data Rows
                  ...history.map((record, index) => new TableRow({
                    children: [
                      (index + 1).toString(),
                      new Date(record.timestamp).toLocaleDateString('id-ID'),
                      record.officialName,
                      record.type,
                      record.status === 'APPROVED' ? 'DISETUJUI' : record.status === 'REJECTED' ? 'DITOLAK' : 'PENDING',
                      record.note || '-'
                    ].map(text => new TableCell({
                      children: [new Paragraph({ children: [new TextRun({ text, size: 18 })] })]
                    }))
                  }))
                ]
              }),

              new Paragraph({ children: [new TextRun({ text: "", break: 2 })] }),

              // Signature Area
              new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                borders: {
                  top: { style: BorderStyle.NONE },
                  bottom: { style: BorderStyle.NONE },
                  left: { style: BorderStyle.NONE },
                  right: { style: BorderStyle.NONE },
                  insideHorizontal: { style: BorderStyle.NONE },
                  insideVertical: { style: BorderStyle.NONE },
                },
                rows: [
                  new TableRow({
                    children: [
                      new TableCell({ width: { size: 60, type: WidthType.PERCENTAGE }, children: [] }),
                      new TableCell({
                        width: { size: 40, type: WidthType.PERCENTAGE },
                        children: [
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [new TextRun({ text: `Karangsari, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`, size: 20 })]
                          }),
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [new TextRun({ text: "Kaur TU dan Umum", size: 20, bold: true })]
                          }),
                          new Paragraph({ children: [new TextRun({ text: "", break: 4 })] }),
                          new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [new TextRun({ text: "DERI DESKO", size: 20, bold: true, underline: {} })]
                          }),
                        ]
                      })
                    ]
                  })
                ]
              })
            ],
          },
        ],
      });

      const blob = await Packer.toBlob(doc);
      saveAs(blob, `LAPORAN_ABSENSI_${new Date().toISOString().split('T')[0]}.docx`);
    } catch (error) {
      console.error("Export error:", error);
    } finally {
      setTimeout(() => setIsExportingWord(false), 1000);
    }
  };

  const exportToExcel = () => {
    setIsExporting(true);
    try {
      // Define Header/Kop Surat rows
      const kopSurat = [
        ['PEMERINTAH KABUPATEN GARUT'],
        ['KECAMATAN PAKENJENG'],
        ['DESA KARANGSARI'],
        ['Alamat : Kp. Mekarsari RT 001 RW 013 Desa Karangsari Kec. Pakenjeng Kab. Garut 44164'],
        ['Email : desakarangsari497@gmail.com | Website : https://Karangsari.id'],
        [''],
        ['LAPORAN REKAPITULASI KEHADIRAN PERANGKAT DESA'],
        [`Tanggal Cetak: ${new Date().toLocaleDateString('id-ID')} ${new Date().toLocaleTimeString('id-ID')}`],
        [''],
        ['No', 'Tanggal', 'Waktu', 'Nama Perangkat', 'Tipe Absen', 'Status Verifikasi', 'Keterangan', 'Koordinat GPS', 'Akurasi GPS (meter)', 'Link Lokasi']
      ];

      // Map history records to rows
      const rows = history.map((record, index) => [
        index + 1,
        new Date(record.timestamp).toLocaleDateString('id-ID'),
        new Date(record.timestamp).toLocaleTimeString('id-ID'),
        record.officialName,
        record.type,
        record.status === 'APPROVED' ? 'DISETUJUI' : record.status === 'REJECTED' ? 'DITOLAK' : 'MENUNGGU KONFIRMASI',
        record.note || '-',
        `${record.location.lat}, ${record.location.lng}`,
        Math.round(record.location.accuracy),
        `https://www.google.com/maps?q=${record.location.lat},${record.location.lng}`
      ]);

      // Create Worksheet from AOA (Array of Arrays)
      const worksheet = XLSX.utils.aoa_to_sheet([...kopSurat, ...rows]);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Laporan Absensi SIAP');
      
      // Merge cells for Kop Surat (0-indexed: r=row, c=column)
      worksheet['!merges'] = [
        { s: { r: 0, c: 0 }, e: { r: 0, c: 9 } }, // Row 1: Kab
        { s: { r: 1, c: 0 }, e: { r: 1, c: 9 } }, // Row 2: Kec
        { s: { r: 2, c: 0 }, e: { r: 2, c: 9 } }, // Row 3: Desa
        { s: { r: 3, c: 0 }, e: { r: 3, c: 9 } }, // Row 4: Alamat
        { s: { r: 4, c: 0 }, e: { r: 4, c: 9 } }, // Row 5: Contact info
        { s: { r: 6, c: 0 }, e: { r: 6, c: 9 } }, // Row 7: Title
        { s: { r: 7, c: 0 }, e: { r: 7, c: 9 } }, // Row 8: Print Date
      ];

      // Auto-size columns
      const wscols = [
        {wch: 5}, {wch: 15}, {wch: 15}, {wch: 25}, {wch: 15}, {wch: 25}, {wch: 30}, {wch: 30}, {wch: 20}, {wch: 40}
      ];
      worksheet['!cols'] = wscols;

      XLSX.writeFile(workbook, `LAPORAN_ABSENSI_KARANGSARI_${new Date().toISOString().split('T')[0]}.xlsx`);
    } finally {
      setTimeout(() => setIsExporting(false), 1000);
    }
  };

  const filteredHistory = history.filter(h => 
    h.officialName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const updateStatus = (id: string, status: 'APPROVED' | 'REJECTED') => {
    const freshHistory = storage.getAttendance(); // Get latest from storage
    const updatedHistory = freshHistory.map(h => 
      h.id === id ? { ...h, status, approvedBy: 'Admin' } : h
    );
    storage.saveAllAttendance(updatedHistory);
    setHistory(updatedHistory.sort((a, b) => b.timestamp - a.timestamp));
  };

  const stats = {
    total: history.length,
    masuk: history.filter(h => h.type === 'MASUK').length,
    pulang: history.filter(h => h.type === 'PULANG').length,
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Riwayat & Laporan</h2>
          <p className="text-slate-500 text-sm">Monitor dan unduh data kehadiran perangkat desa</p>
        </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={refreshData}
              className="p-2.5 bg-white border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition"
              title="Segarkan Data"
            >
              <RefreshCw size={20} />
            </button>
            <button
              onClick={exportToExcel}
              disabled={history.length === 0 || isExporting}
              className="bg-green-600 text-white px-5 py-2.5 rounded-xl flex items-center gap-2 hover:bg-green-700 transition shadow-lg shadow-green-100 disabled:bg-slate-300 disabled:shadow-none"
            >
              {isExporting ? <RefreshCw size={20} className="animate-spin" /> : <FileSpreadsheet size={20} />}
              <span className="hidden sm:inline">{isExporting ? 'Memproses...' : 'Excel'}</span>
            </button>
            <button
              onClick={exportToWord}
              disabled={history.length === 0 || isExportingWord}
              className="bg-blue-600 text-white px-5 py-2.5 rounded-xl flex items-center gap-2 hover:bg-blue-700 transition shadow-lg shadow-blue-100 disabled:bg-slate-300 disabled:shadow-none"
            >
              {isExportingWord ? <RefreshCw size={20} className="animate-spin" /> : <FileText size={20} />}
              <span className="hidden sm:inline">{isExportingWord ? 'Memproses...' : 'Word'}</span>
            </button>
          </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard label="Total Absensi" value={stats.total} icon={<Calendar className="text-blue-500" />} />
        <StatCard label="Absen Datang" value={stats.masuk} icon={<LogIn className="text-green-500" />} />
        <StatCard label="Absen Pulang" value={stats.pulang} icon={<LogOut className="text-red-500" />} />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder="Cari berdasarkan nama perangkat..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-brand-blue"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider">
                <th className="px-6 py-4">Poto Selfie</th>
                <th className="px-6 py-4">Nama Perangkat</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Keterangan</th>
                <th className="px-6 py-4">Waktu</th>
                <th className="px-6 py-4">Lokasi GPS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHistory.map((record) => (
                <tr key={record.id} className="hover:bg-slate-50/50 transition">
                  <td className="px-6 py-4">
                    <div className="w-12 h-12 rounded-lg bg-slate-100 border border-slate-200 overflow-hidden shadow-inner">
                      <img src={record.photo} alt="Selfie" className="w-full h-full object-cover" />
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-bold text-slate-800">{record.officialName}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-black tracking-wider shadow-sm text-center ${
                        record.type === 'MASUK' ? 'bg-green-100 text-green-700' : 
                        record.type === 'PULANG' ? 'bg-red-100 text-red-700' :
                        record.type === 'IZIN' ? 'bg-amber-100 text-amber-700' : 'bg-purple-100 text-purple-700'
                      }`}>
                        {record.type === 'TUGAS_LUAR' ? 'TUGAS LAPANGAN' : record.type === 'IZIN' ? 'IZIN KELUARGA' : record.type}
                      </span>
                      <span className={`text-[8px] font-bold text-center border rounded py-0.5 ${
                        record.status === 'APPROVED' ? 'bg-blue-50 border-blue-200 text-blue-600' :
                        record.status === 'REJECTED' ? 'bg-red-50 border-red-200 text-red-600' : 
                        'bg-amber-50 border-amber-200 text-amber-600'
                      }`}>
                        {record.status === 'APPROVED' ? 'DISETUJUI' : record.status === 'REJECTED' ? 'DITOLAK' : 'MENUNGGU KONFIRMASI'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-xs text-slate-600 max-w-[150px] truncate" title={record.note}>
                      {record.note || '-'}
                    </p>
                    {(!record.status || record.status === 'PENDING') && isAdmin && (
                      <div className="flex gap-2 mt-3 w-full">
                        <button 
                          onClick={() => updateStatus(record.id, 'APPROVED')}
                          className="flex-1 px-3 py-2 bg-green-600 text-white text-[10px] font-black rounded-lg hover:bg-green-700 shadow-sm flex items-center justify-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
                        >
                          <CheckCircle2 size={14} />
                          SETUJUI
                        </button>
                        <button 
                          onClick={() => updateStatus(record.id, 'REJECTED')}
                          className="flex-1 px-3 py-2 bg-red-600 text-white text-[10px] font-black rounded-lg hover:bg-red-700 shadow-sm flex items-center justify-center gap-1.5 transition-all active:scale-95 whitespace-nowrap"
                        >
                          <AlertCircle size={14} />
                          TOLAK
                        </button>
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5 text-slate-700 font-bold text-sm">
                        <Clock size={12} className="text-slate-400" />
                        {formatTime(new Date(record.timestamp))}
                      </div>
                      <div className="text-[10px] text-slate-400 font-medium">
                        {new Date(record.timestamp).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <a 
                      href={`https://www.google.com/maps?q=${record.location.lat},${record.location.lng}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-[10px] text-blue-600 hover:text-blue-800 font-bold bg-blue-50 px-2 py-1 rounded-md border border-blue-100 transition"
                    >
                      <MapPin size={12} />
                      BUKA GOOGLE MAPS
                    </a>
                  </td>
                </tr>
              ))}
              {filteredHistory.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-16 text-center">
                    <div className="flex flex-col items-center gap-2 opacity-30">
                      <FileSpreadsheet size={48} />
                      <p className="font-semibold">Belum ada data absensi untuk ditampilkan.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string, value: number, icon: React.ReactNode }) {
  return (
    <div className="bg-white p-5 rounded-2xl border border-slate-200 flex items-center justify-between shadow-sm">
      <div className="space-y-1">
        <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-black text-slate-900">{value}</p>
      </div>
      <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-xl shadow-inner border border-slate-100">
        {icon}
      </div>
    </div>
  );
}

