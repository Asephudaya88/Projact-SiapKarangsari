
export interface Official {
  id: string;
  officialId: string; // NIK/NIPD
  name: string;
  position: string;
  address: string;
  createdAt: number;
}

export interface AttendanceRecord {
  id: string;
  officialId: string;
  officialName: string;
  type: 'MASUK' | 'PULANG' | 'IZIN' | 'TUGAS_LUAR';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  approvedBy?: string;
  timestamp: number;
  photo: string;
  location: {
    lat: number;
    lng: number;
    accuracy: number;
  };
  note?: string;
}

export const WORK_HOURS = {
  START: '07:30',
  END: '15:30',
};
